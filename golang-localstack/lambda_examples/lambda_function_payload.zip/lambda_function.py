# lambda_function.py

def lambda_handler(event, context):
    return {
        'statusCode': 200,
        'body': 'ping pong'
    }
